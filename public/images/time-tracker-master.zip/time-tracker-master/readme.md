## ANS Time Tracker

ANS Time Tracker is an app based in Laravel to store and list time spend in projects and works.

## API

You can connect with ANS Time Tracker using [anavallasuiza/time-tracker-sync](http://github.com/anavallasuiza/time-tracker-sync) which allow import tracking databases from [Hamster](http://projecthamster.wordpress.com/screenshots/) or [Time Tracker for Mac](https://code.google.com/p/time-tracker-mac/).

### License

The Laravel framework AND ANS Time Tracker is open-sourced software licensed under the [MIT license](http://opensource.org/licenses/MIT)
