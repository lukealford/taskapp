<div class="text-center">
    <h1><?= _('Error 401 - Unauthorized'); ?></h1>

    <div class="alert alert-warning">
        <?= _('Sorry but you have not authorization to view this site'); ?>
    </div>
</div>