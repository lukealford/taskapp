<div class="text-center">
    <h1><?= _('Error 404 - Not Found'); ?></h1>

    <div class="alert alert-warning">
        <?= _('Sorry. The page you are looking for does not exist.'); ?>
    </div>

    <p>We may have removed a page to which you found a link, or you may have the wrong address for the page you are looking for</p>
</div>